import { Component } from '@angular/core';
import { CommonModule } from '@angular/common';
import { RouterModule } from '@angular/router';
import { Observable } from 'rxjs'; 
import { CartService } from '../../services/cart.service'; 

@Component({
  selector: 'app-navbar',
  standalone: true,
  imports: [CommonModule, RouterModule],
  templateUrl: './navbar.component.html',
  styleUrl: './navbar.component.css'
})
export class NavbarComponent {
  menuActive = false;

  cartCount!: Observable<number>;

  constructor(private cartService: CartService) {
    this.cartCount = this.cartService.currentCount$;
  }

  toggleMenu() {
    this.menuActive = !this.menuActive;
  }
}